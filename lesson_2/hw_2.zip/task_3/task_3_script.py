'''Задание №3 к уроку 2'''

from yaml import dump, load, FullLoader

FIRST_ELEMENT = ['первый элемент списка',
                 'второй элемент списка',
                 'третий элемент списка']

SECOND_ELEMENT = 365

THIRD_ELEMENT = {'white chess king': '\u2654',
                 'white chess queen': '\u2655',
                 'white chess rook': '\u2656',
                 'white chess bishop': '\u2657',
                 'white chess knight': '\u2658',
                 'white chess pawn': '\u2659',
                 'black chess king': '\u265A',
                 'black chess queen': '\u265B',
                 'black chess rook': '\u265C',
                 'black chess bishop': '\u265D',
                 'black chess knight': '\u265E',
                 'black chess pawn': '\u265F',
                 }

DATA_TO_YAML = [FIRST_ELEMENT, SECOND_ELEMENT, THIRD_ELEMENT]

with open('data_dump.yaml', 'w', encoding='utf-8') as file:
    dump(
        DATA_TO_YAML,
        file,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False)

with open('data_dump.yaml', encoding='utf-8') as file:
    READ_DATA = load(file, Loader=FullLoader)

if DATA_TO_YAML == READ_DATA:
    print('Записанные и считанные данные из YAML-файла совпадают')
else:
    print('Записанные и считанные данные из YAML-файла Не совпадают!')
