'''Задание № 2 к уроку 2'''

from json import load, dump
from datetime import datetime

# параметр 'data' в функции добавляется из системного времени


def write_order_to_json(item, quantity, price, buyer):
    # читаем данные из файла
    with open('orders.json', 'r', encoding='utf-8') as json_data:
        data = load(json_data)
    # формируем новые данные для записи в json-файл
    add_data = {
        'item': item,
        'quantity': quantity,
        'price': price,
        'buyer': buyer,
        'data': datetime.strftime(
            datetime.now(),
            "%Y.%m.%d %H:%M:%S")}
    data['orders'].append(add_data)
    with open('orders.json', 'w', encoding='utf-8') as json_data_updated:
        dump(
            data,
            json_data_updated,
            indent=4,
            sort_keys=True,
            ensure_ascii=False)


if __name__ == '__main__':
    write_order_to_json('болты', 300, 500, 'Алексей')
    write_order_to_json('сапоги', 5, 400, 'Дмитрий')
    write_order_to_json('набор ручных инструментов', 2, 4000, 'Евгений')
