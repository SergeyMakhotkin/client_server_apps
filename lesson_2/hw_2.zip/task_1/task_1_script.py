'''Задание №1 к уроку 2'''

from os import listdir
from os.path import isfile
from csv import DictWriter
from re import match, search


# функция для извлечение информации из файлов. в качестве аргументов передаем функции значения ключей поиска
def get_data(*args):
    # формируем список аргументов, которые будем искать в файле
    main_data = {arg: [] for arg in args}
    # формируем список файлов в текущей папке, имена которорых удовлетворяет шаблону
    list_of_files = [el for el in listdir(path=".") if match(r'^info_[0-9]*\.txt$', el) and isfile(el)]
    # перебираем все подходящие файлы
    for file in list_of_files:
        with open(file, encoding='cp1251') as f:
            for row in f:
                # проверяем соответствие строки интересующему нас шаблону
                for pattern in main_data.keys():
                    if search(pattern, row):
                        main_data[pattern].append(row.split(sep=':', maxsplit=2)[1].strip())
                        # добавляем данные в соответствующий список словаря main_data

    # приведем список к виду, подходящему для записи методом DictWriter
    result = [{} for _ in range(len(list_of_files))]
    for key in main_data.keys():
        for num, value in enumerate(main_data[key]):
            result[num][key] = value
    return result


def write_to_csv(file_name, *args):
    data_for_writing = get_data(*args)
    with open(file_name, 'w', encoding='utf-8', newline='') as file:
        file_writer = DictWriter(
            file, fieldnames=list(
                data_for_writing[0].keys()))
        file_writer.writeheader()
        for line in data_for_writing:
            file_writer.writerow(line)


if __name__ == '__main__':
    write_to_csv(
        'result_data.csv',
        'Название ОС',
        'Изготовитель ОС',
        'Код продукта',
        'Тип системы')
